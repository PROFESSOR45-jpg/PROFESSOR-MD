/* 𝗚𝗜𝗙𝗧𝗘𝗗-𝗠𝗗 𝗩𝟱 */

(function (_0x4cf74c, _0x1bd01e) {
    const _0x459a0e = _0x1aa7, _0x26b0f4 = _0x4cf74c();
    while (!![]) {
        try {
            const _0x1ebb14 = -parseInt(_0x459a0e(0x1a5)) / (-0x6b9 + 0x3fc + -0x75 * -0x6) + parseInt(_0x459a0e(0x1d4)) / (0x661 * -0x5 + 0x8e6 + 0x1701) + parseInt(_0x459a0e(0x1a6)) / (0x1aca + -0x728 + -0x1 * 0x139f) * (-parseInt(_0x459a0e(0x17f)) / (-0x158 * -0x19 + -0x1 * 0xb79 + -0x161b)) + -parseInt(_0x459a0e(0x16e)) / (-0x1f0a + 0x3 * 0x152 + 0x7 * 0x3df) * (-parseInt(_0x459a0e(0x1b4)) / (-0x1993 * -0x1 + -0x6 * -0x607 + -0x3db7)) + -parseInt(_0x459a0e(0x184)) / (0x8d4 * 0x3 + -0x4 * -0x60a + 0x73b * -0x7) + -parseInt(_0x459a0e(0x1d9)) / (-0x4c1 * 0x5 + 0xae0 + 0xced * 0x1) * (-parseInt(_0x459a0e(0x189)) / (0x1f * -0x119 + -0x1d0 + -0x11f * -0x20)) + -parseInt(_0x459a0e(0x1c9)) / (-0x16f4 + 0xd * 0xb5 + 0xdcd) * (-parseInt(_0x459a0e(0x1cd)) / (-0x1d53 * -0x1 + 0x1b08 + -0x3850));
            if (_0x1ebb14 === _0x1bd01e)
                break;
            else
                _0x26b0f4['push'](_0x26b0f4['shift']());
        } catch (_0x3efcdb) {
            _0x26b0f4['push'](_0x26b0f4['shift']());
        }
    }
}(_0x64d0, 0x30d8b + -0xf * -0xdffd + -0x728dd));
function _0x1aa7(_0x2c8ee9, _0x38904d) {
    const _0x4a6551 = _0x64d0();
    return _0x1aa7 = function (_0x39fcc3, _0x264ade) {
        _0x39fcc3 = _0x39fcc3 - (-0x17d9 + 0x26cd + -0xd91);
        let _0x22f56a = _0x4a6551[_0x39fcc3];
        return _0x22f56a;
    }, _0x1aa7(_0x2c8ee9, _0x38904d);
}
import _0x44845b from 'axios';
import _0x3c4d2, { prepareWAMessageMedia } from '@whiskeysockets/baileys';
function _0x64d0() {
    const _0x3e25ae = [
        '71622GsOMMU',
        'nse:',
        '*\x0aUse\x20it\x20t',
        'VDeGH',
        '_,*\x0aPlease',
        'Minute\x20Bef',
        'QpZaH',
        '-main.onre',
        'https://wh',
        'ing\x20Gifted',
        'sponse\x20fro',
        '.menu',
        'se\x20from\x20Gi',
        'aWBep',
        'React',
        'data',
        'DmwrT',
        'after,\x20Obt',
        'JJiJZ',
        'credspair',
        '711111111',
        '10770NdTPah',
        '𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕',
        'remoteJid',
        'copy_code',
        '2057AANzyo',
        '\x20is:\x20*',
        'ʀɪɴɢ\x20ᴄᴏᴅᴇ',
        'startsWith',
        'toLowerCas',
        'WnUxk',
        'credssessi',
        '2244922BgylSu',
        'cFoDk',
        'error',
        'ating\x20Your',
        'ᴍᴀɪɴ\x20ᴍᴇɴᴜ',
        '1346104MtWbAX',
        'mtrUF',
        'length',
        'ode?number',
        'eMessage',
        'Error\x20gett',
        'fted\x20Api.',
        'PI.',
        'fted-creds',
        'cta_copy',
        'cta_url',
        'Message',
        'TLoVn',
        'sʜᴏᴡ\x20💜\x20ғᴏʀ',
        'm\x20Gifted\x20A',
        'pushName',
        'reply',
        '\x20Provide\x20P',
        'message',
        'r\x20in\x20Inter',
        'ode...',
        '*Gifted-Md',
        '\x20Within\x201\x20',
        'Invalid\x20re',
        'Body',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆',
        '*\x20is\x20Gener',
        'loyment!!!',
        'quick_repl',
        'ain\x20Your\x20C',
        'trim',
        '435mqRfQM',
        'getcreds',
        '/channel/0',
        'create',
        'gn\x0aEg\x20.cre',
        'get',
        'relayMessa',
        '029VaYauR9',
        'stringify',
        'i1l',
        'kDVLN',
        '\x20Pairing\x20C',
        'https://gi',
        '𝟓*',
        'ISTkHTj4xv',
        'mfOzx',
        'body',
        '4uuhEuC',
        'key',
        'NativeFlow',
        'airingCode',
        'vVPbL',
        '7058681WJSicZ',
        'out\x20(+)\x20Si',
        '\x20APi\x20respo',
        'bXQZF',
        '\x20ɢɪғᴛᴇᴅ',
        '45TyvKPz',
        'ormat\x20With',
        'ifted-Md\x20P',
        'py\x20Bot\x20Dep',
        'ires\x0aThere',
        'from',
        'includes',
        'A\x20moment,\x20',
        'rLTIq',
        'ing\x20respon',
        'national\x20F',
        'atsapp.com',
        'code',
        'tRLeH',
        'VVKce',
        'dRVYb',
        'ʀ\x20ᴄᴏᴅᴇ',
        'split',
        'o\x20Link\x20You',
        'Dear\x20*_',
        'igZPk',
        'match',
        '\x20File.\x0aHap',
        '📋\x20ᴄᴏᴘʏ\x20ᴘᴀɪ',
        'slice',
        'nder.com/c',
        '_*,\x0aYour\x20G',
        'Footer',
        '1174247YXwPoP',
        '1290261KDvVvr',
        '📋\x20ᴄᴏᴘʏ\x20ʏᴏᴜ',
        'jfeTJ',
        'kisdj',
        'Deployment',
        'ore\x20it\x20Exp',
        'Hello\x20*_',
        'hone\x20Numbe',
        'Header',
        'reds.json\x20',
        'r\x20WhatsApp',
        'push',
        'dspair\x20254',
        'Interactiv'
    ];
    _0x64d0 = function () {
        return _0x3e25ae;
    };
    return _0x64d0();
}
const {generateWAMessageFromContent, proto} = _0x3c4d2, GetCreds = async (_0xe93762, _0x4e03d4) => {
        const _0x553dcc = _0x1aa7, _0x3077ec = {
                'vVPbL': function (_0x403de3, _0x296900) {
                    return _0x403de3 + _0x296900;
                },
                'WnUxk': _0x553dcc(0x1c7),
                'kisdj': _0x553dcc(0x16f),
                'dRVYb': _0x553dcc(0x1d3) + 'on',
                'mfOzx': _0x553dcc(0x190) + _0x553dcc(0x164) + _0x553dcc(0x169) + _0x553dcc(0x1d7) + _0x553dcc(0x179) + _0x553dcc(0x163),
                'QpZaH': function (_0xbb6cbf, _0x28c38c) {
                    return _0xbb6cbf(_0x28c38c);
                },
                'igZPk': _0x553dcc(0x1e2),
                'TLoVn': _0x553dcc(0x1a7) + _0x553dcc(0x199),
                'VVKce': _0x553dcc(0x1cc),
                'bXQZF': _0x553dcc(0x16b) + 'y',
                'aWBep': _0x553dcc(0x1d8),
                'JJiJZ': _0x553dcc(0x1bf),
                'jfeTJ': _0x553dcc(0x1a0) + _0x553dcc(0x1cf),
                'mtrUF': _0x553dcc(0x1e3),
                'DmwrT': _0x553dcc(0x1e6) + _0x553dcc(0x188),
                'tRLeH': function (_0x263144, _0x30626c, _0xb82b1, _0x585ece) {
                    return _0x263144(_0x30626c, _0xb82b1, _0x585ece);
                },
                'kDVLN': _0x553dcc(0x168) + _0x553dcc(0x1ca) + _0x553dcc(0x17b),
                'VDeGH': _0x553dcc(0x166) + _0x553dcc(0x1be) + _0x553dcc(0x1e7) + _0x553dcc(0x1e0),
                'cFoDk': _0x553dcc(0x1de) + _0x553dcc(0x1bd) + _0x553dcc(0x186) + _0x553dcc(0x1b5),
                'rLTIq': _0x553dcc(0x1de) + _0x553dcc(0x192) + _0x553dcc(0x1c0) + _0x553dcc(0x1df)
            }, _0x220a20 = _0xe93762[_0x553dcc(0x17e)][_0x553dcc(0x19e)](/^[\\/!#.]/), _0x2907f5 = _0x220a20 ? _0x220a20[0x1419 + -0x1e88 + 0xa6f] : '/', _0x5b8ef6 = _0xe93762[_0x553dcc(0x17e)][_0x553dcc(0x1d0)](_0x2907f5) ? _0xe93762[_0x553dcc(0x17e)][_0x553dcc(0x1a1)](_0x2907f5[_0x553dcc(0x1db)])[_0x553dcc(0x19a)]('\x20')[0xd2b * -0x1 + 0x1 * 0x1fdd + -0x12b2][_0x553dcc(0x1d1) + 'e']() : '', _0xd49b1f = _0xe93762[_0x553dcc(0x17e)][_0x553dcc(0x1a1)](_0x3077ec[_0x553dcc(0x183)](_0x2907f5[_0x553dcc(0x1db)], _0x5b8ef6[_0x553dcc(0x1db)]))[_0x553dcc(0x16d)](), _0x4eb8ba = [
                _0x3077ec[_0x553dcc(0x1d2)],
                _0x3077ec[_0x553dcc(0x1a9)],
                _0x3077ec[_0x553dcc(0x198)]
            ];
        if (_0x4eb8ba[_0x553dcc(0x18f)](_0x5b8ef6)) {
            if (!_0xd49b1f)
                return _0xe93762[_0x553dcc(0x1e9)](_0x553dcc(0x1ac) + _0xe93762[_0x553dcc(0x1e8)] + (_0x553dcc(0x1b8) + _0x553dcc(0x1ea) + _0x553dcc(0x1ad) + _0x553dcc(0x1ec) + _0x553dcc(0x193) + _0x553dcc(0x18a) + _0x553dcc(0x185) + _0x553dcc(0x172) + _0x553dcc(0x1b2) + _0x553dcc(0x1c8)));
            try {
                await _0xe93762[_0x553dcc(0x1c2)]('🕘'), await _0xe93762[_0x553dcc(0x1e9)](_0x3077ec[_0x553dcc(0x17d)]);
                const _0x26a2e5 = _0x553dcc(0x17a) + _0x553dcc(0x1e1) + _0x553dcc(0x1bb) + _0x553dcc(0x1a2) + _0x553dcc(0x1dc) + '=' + _0x3077ec[_0x553dcc(0x1ba)](encodeURIComponent, _0xd49b1f), _0x460fdc = await _0x44845b[_0x553dcc(0x173)](_0x26a2e5), _0x4fe4d5 = _0x460fdc[_0x553dcc(0x1c3)];
                if (_0x4fe4d5 && _0x4fe4d5[_0x553dcc(0x195)]) {
                    const _0x10d5d8 = _0x4fe4d5[_0x553dcc(0x195)], _0x57b1c2 = _0x553dcc(0x19c) + _0xe93762[_0x553dcc(0x1e8)] + (_0x553dcc(0x1a3) + _0x553dcc(0x18b) + _0x553dcc(0x182) + _0x553dcc(0x1ce)) + _0x10d5d8 + (_0x553dcc(0x1b6) + _0x553dcc(0x19b) + _0x553dcc(0x1b0) + _0x553dcc(0x165) + _0x553dcc(0x1b9) + _0x553dcc(0x1ab) + _0x553dcc(0x18d) + _0x553dcc(0x1c5) + _0x553dcc(0x16c) + _0x553dcc(0x1af) + _0x553dcc(0x1aa) + _0x553dcc(0x19f) + _0x553dcc(0x18c) + _0x553dcc(0x16a)), _0x568b85 = _0x57b1c2[_0x553dcc(0x19e)](/```([\s\S]*?)```/);
                    let _0x471174 = [];
                    if (_0x568b85) {
                        const _0x38c621 = _0x568b85[0x15e3 + 0x225c + 0x272 * -0x17];
                        _0x471174[_0x553dcc(0x1b1)]({
                            'name': _0x3077ec[_0x553dcc(0x19d)],
                            'buttonParamsJson': JSON[_0x553dcc(0x176)]({
                                'display_text': _0x3077ec[_0x553dcc(0x1e5)],
                                'id': _0x3077ec[_0x553dcc(0x197)],
                                'copy_code': _0x10d5d8
                            })
                        });
                    }
                    _0x471174[_0x553dcc(0x1b1)]({
                        'name': _0x3077ec[_0x553dcc(0x187)],
                        'buttonParamsJson': JSON[_0x553dcc(0x176)]({
                            'display_text': _0x3077ec[_0x553dcc(0x1c1)],
                            'id': _0x3077ec[_0x553dcc(0x1c6)]
                        })
                    }, {
                        'name': _0x3077ec[_0x553dcc(0x19d)],
                        'buttonParamsJson': JSON[_0x553dcc(0x176)]({
                            'display_text': _0x3077ec[_0x553dcc(0x1a8)],
                            'id': _0x3077ec[_0x553dcc(0x197)],
                            'copy_code': _0x10d5d8
                        })
                    }, {
                        'name': _0x3077ec[_0x553dcc(0x1da)],
                        'buttonParamsJson': JSON[_0x553dcc(0x176)]({
                            'display_text': _0x3077ec[_0x553dcc(0x1c4)],
                            'url': _0x553dcc(0x1bc) + _0x553dcc(0x194) + _0x553dcc(0x170) + _0x553dcc(0x175) + _0x553dcc(0x17c) + _0x553dcc(0x177)
                        })
                    });
                    let _0x22a78d = _0x3077ec[_0x553dcc(0x196)](generateWAMessageFromContent, _0xe93762[_0x553dcc(0x18e)], {
                        'viewOnceMessage': {
                            'message': {
                                'messageContextInfo': {
                                    'deviceListMetadata': {},
                                    'deviceListMetadataVersion': 0x2
                                },
                                'interactiveMessage': proto[_0x553dcc(0x1e4)][_0x553dcc(0x1b3) + _0x553dcc(0x1dd)][_0x553dcc(0x171)]({
                                    'body': proto[_0x553dcc(0x1e4)][_0x553dcc(0x1b3) + _0x553dcc(0x1dd)][_0x553dcc(0x167)][_0x553dcc(0x171)]({ 'text': _0x57b1c2 }),
                                    'footer': proto[_0x553dcc(0x1e4)][_0x553dcc(0x1b3) + _0x553dcc(0x1dd)][_0x553dcc(0x1a4)][_0x553dcc(0x171)]({ 'text': _0x3077ec[_0x553dcc(0x178)] }),
                                    'header': proto[_0x553dcc(0x1e4)][_0x553dcc(0x1b3) + _0x553dcc(0x1dd)][_0x553dcc(0x1ae)][_0x553dcc(0x171)]({
                                        'title': '',
                                        'subtitle': '',
                                        'hasMediaAttachment': ![]
                                    }),
                                    'nativeFlowMessage': proto[_0x553dcc(0x1e4)][_0x553dcc(0x1b3) + _0x553dcc(0x1dd)][_0x553dcc(0x181) + _0x553dcc(0x1e4)][_0x553dcc(0x171)]({ 'buttons': _0x471174 })
                                })
                            }
                        }
                    }, {});
                    await _0x4e03d4[_0x553dcc(0x174) + 'ge'](_0x22a78d[_0x553dcc(0x180)][_0x553dcc(0x1cb)], _0x22a78d[_0x553dcc(0x1eb)], { 'messageId': _0x22a78d[_0x553dcc(0x180)]['id'] }), await _0xe93762[_0x553dcc(0x1c2)]('✅');
                } else
                    throw new Error(_0x3077ec[_0x553dcc(0x1b7)]);
            } catch (_0x1ca59d) {
                console[_0x553dcc(0x1d6)](_0x3077ec[_0x553dcc(0x1d5)], _0x1ca59d[_0x553dcc(0x1eb)]), _0xe93762[_0x553dcc(0x1e9)](_0x3077ec[_0x553dcc(0x191)]), await _0xe93762[_0x553dcc(0x1c2)]('❌');
            }
        }
    };
export default GetCreds;

/* 𝗚𝗜𝗙𝗧𝗘𝗗-𝗠𝗗 𝗩𝟱 */
